from django.contrib import admin
from home.models import Sign,Appointment
# Register your models here.
admin.site.register(Sign)
#admin.site.register(Login)
admin.site.register(Appointment)